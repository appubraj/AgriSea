import validate from './validate'
import { Router } from 'express';


export default ({ config, db }) => {
	let routes = Router();

	// add middleware here

	return routes;
}
export { validate }