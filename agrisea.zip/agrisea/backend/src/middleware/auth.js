import adminModel from '../modules/Admin/adminModel'
// import collectorModel from '../modules/collector/collectorModel'
import BranchManagerModel from '../modules/BranchManager/BranchManagerModel'
import jwt from 'jsonwebtoken'
import mongoose from "mongoose";

const { JWT_SECRET } = process.env

const auth = async(req, res, next) => {
    try {
        const token = req.header('Authorization').replace('Bearer ', '')
        const data = jwt.verify(token, JWT_SECRET)
        //console.log(`data._id `, data._id)
        //console.log(`token `, token)
        const user = await adminModel.findOne({ _id: data._id, 'tokens.token': token })

        if (!user) {
            throw new Error()
        }
        req.user = user
        req.token = token
        next()
    } catch (error) {
        res.status(401).send({ error: 'Not authorized to access this resource' })
    }
}

const collectorAuth = async(req, res, next) => {
    try {
        const token = req.header('Authorization').replace('Bearer ', '')
        const data = jwt.verify(token, JWT_SECRET)
        let role = req.header('role')
        const user = await mongoose.model(`${role}`).findOne({ _id: data._id, 'tokens.token': token })
        if (!user) {
            throw new Error()
        }
        req.user = user
        req.token = token
        next()
    } catch (error) {
        res.status(401).send({ error: 'Not authorized to access this resource' })
    }
}

const verifyToken = async(req, res, next) => {
    try {
        const token = req.header('Authorization').replace('Bearer ', '')
        const data = jwt.verify(token, JWT_SECRET)
        console.log(`data `, data)
        let role = req.header('role')
        const user = await mongoose.model(`${data.role}`).findOne({ _id: data._id, 'tokens.token': token })
        if (!user) {
            throw new Error()
        }
        req.user = user
        req.token = token
        next()
    } catch (error) {
        res.status(401).send({ error: 'Not authorized to access this token' })
    }
}

const BranchManagerAuth = async(req, res, next) => {
    try {
        const token = req.header('Authorization').replace('Bearer ', '')
        const data = jwt.verify(token, JWT_SECRET)
        //console.log(`data._id `, data._id)
        //console.log(`token `, token)
        const user = await BranchManagerModel.findOne({ _id: data._id, 'tokens.token': token })

        if (!user) {
            throw new Error()
        }
        req.user = user
        req.token = token
        next()
    } catch (error) {
        res.status(401).send({ error: 'Not authorized to access this resource' })
    }
}

export { auth, collectorAuth, BranchManagerAuth, verifyToken }