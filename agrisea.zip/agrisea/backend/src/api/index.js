import { version } from "../../package.json";
import express from "express";
// import facets from "./facets";
// import GroupModule from "../modules/Group";
// import ClusterModule from "../modules/Cluster";
// import AdminModule from "../modules/Admin";
// import CollectionModule from "../modules/Collections";
// import MobileModule from "../modules/Mobile";
// import BranchManagerModule from "../modules/BranchManager";

import FormersModule from "../modules/Agro_sea_former"
import ConsumerModule from "../modules/Consumer";
import AccountsModule from "../modules/Accounts"
const app = express();

// // app.use("/role", RoleModule);
// app.use("/group", GroupModule);
// app.use("/cluster",ClusterModule);
// app.use("/admin", AdminModule);
// app.use("/collections",CollectionModule);
// app.use("/mobile",MobileModule);
// app.use("BranchManager",BranchManagerModule);
app.use("/accounts", AccountsModule)
app.use("/consumer", ConsumerModule)
app.use("/formers", FormersModule)


export default app;
