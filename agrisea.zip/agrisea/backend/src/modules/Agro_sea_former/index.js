import { Router } from "express";
import FormersController from "./FormerController";


const router = new Router();
const Controller = new FormersController();
// router.get("/all", Controller.getGroups);
// router.get("/:id", Controller.getGroupById);
// router.get("/all", Controller.getProspects);
// router.get("/:id", Controller.getProspectById);
// router.put("/", Controller.updateGroupById);


router.get("/", Controller.getAllFormers);
router.post("/",Controller.registerFormer)
export default router;
