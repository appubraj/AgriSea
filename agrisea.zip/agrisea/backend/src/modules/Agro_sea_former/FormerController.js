import formerModel from "./FormerModel";

// import { ProspectSchema } from "./ProspectSchema";
// import _ from "lodash";

const axios = require('axios');
class Formers {}

Formers.prototype.registerFormer = async(req, res) => {
  let formersObj = req.body

  console.log(formersObj)
  let model = new formerModel(formersObj)
  model.save((err, result) => {
    if (err) {
      console.log(`err `, err)
      if (err.code == 11000) {
        res.send({
          success: false,
          message: 'uid already exist',
        })
      }
    }
        console.log(result)
        let payload = {
            input: {
              BidPrice: (result.cropDetails[0].minimumBid).toString(),
              CropID: (result.cropDetails[0]._id).toString(),
              Date:result.dob,
              Grade: result.cropDetails[0].grade,
              LandLocation: result.cropDetails[0].landLocation,
              Name: result.cropDetails[0].cropName,
              OwnerID: (result._id).toString(),
              Quantity: result.cropDetails[0].quantity,
              Temperature: "31",
          }
        }
        const config = {
          method: 'post',
          url: 'http://127.0.0.1:5000/api/v1/namespaces/default/apis/asset_transfer/invoke/CreateAsset',
          data: payload,
          }
          axios(config)
          .then(function (response) {
            res.send({
              success: true,
              message: 'Onboarded Succesfully',
            })
          })
          .catch(function (error) {
            res.send(error);
          });

    })

}

Formers.prototype.getAllFormers = (req, res) => {
  formerModel.find({}, (err, result) => {
    if (err) {
      res.send(err);
    } else {
      res.send(result);
    }
  });
};


export default Formers;