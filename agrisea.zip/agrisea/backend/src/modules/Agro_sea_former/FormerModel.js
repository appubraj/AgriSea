import { number } from "joi";
import mongoose from "mongoose";
//import { ProspectSchema } from "./ProspectSchema";
let FormerSchema = new mongoose.Schema(
  {
    uid: { type: String,unique:true},
    fullName: { type: String, default: null },
    dob:{type:Date,default:null},
    mobile:{type:String,default:null},
    address:{type:String,default:null},
    cropDetails: [
        {
            cropName:{type:String,default:null},
            quantity:{type:String,default:null},
            stage:{type:String,default:null},
            fertilizers:{type:String,default:null},
            landLocation:{type:String,default:null},
            grade:{type:String,default:null},
            minimumBid:{type: Number ,default:null},
            currentBid:{type: Number ,default:null}

        }
    ],
  },
 { timestamps: true }
);

// plugin.applyPlugin();
const formerschema = mongoose.model("formerschema", FormerSchema);
export default formerschema;