import accountModel from "./AccountModel";
import accountTransfer from "./AccountModelTransfer"
// import { ProspectSchema } from "./ProspectSchema";
// import _ from "lodash";

// const axios = require('axios');
class account {}

account.prototype.registerAccount = async(req, res) => {
  let accountsObj = req.body

  console.log(accountsObj)
  let model = new accountModel(accountsObj)
  model.save((err, result) => {
    if (err) {
      console.log(`err `, err)
      if (err.code == 11000) {
        res.send({
          success: false,
          message: 'Account number already exist',
        })
      }
    }
        console.log(result)
        res.send(result)
    })

};

account.prototype.getAllAccount = (req, res) => {
  accountModel.find({}, (err, result) => {
    if (err) {
      res.send(err);
    } else {
      res.send(result);
    }
  });
};

// account.prototype.transferMoney = (req, res) => {
//   let accountTObj = req.body;
//   console.log(accountTObj);

//   let id1 = req.body.remmiterDetails.accountNumber;
//   let acc2 = req.body.beneficiaryDetails.accountNumber;
//   let amount = req.body.amount;

//   accountModel.findById(id1, (err, result) => {
//     if (err) {
//       res.send(err);
//     } elseif(result < amount)
//       {
//         res.send(
//           {
//             success: false,
//             message: 'Money Transfer failed due to Insufficient balance',
//           }
//         )
//       }
    
//   });

//   if (req.body.username == "admin" && req.body.password == "adminpw") {
//     let amount = req.body.amount;
//     adminModel.findByIdAndUpdate(id, { password: password }, (err, result) => {
//       if (err) {
//         console.log(`err `, err);
//       } else {
//         console.log(`result `, result);
//       }
//     });
//   }


//   accountModel.findByIdAndUpdate(id1, (err, result) =>
//   {
//     if(err){
//       res.send(err);
//     }
//     else
//   })

// }

export default account;