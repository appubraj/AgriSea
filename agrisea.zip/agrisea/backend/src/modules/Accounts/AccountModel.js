// import { number } from "joi";
// import { number } from "joi";
import mongoose from "mongoose";
//import { ProspectSchema } from "./ProspectSchema";
let AccountopenSchema = new mongoose.Schema(
  {
    acc_Holder: { type: String, default: null },
    Bank:{type:String,default:null},
    Branch:{type:String,default:null},
    IFSC:{type:String,default:null},
    Balance : {type:Number, default: null}
  },
);

// plugin.applyPlugin();
const accountschema = mongoose.model("accoutschema", AccountopenSchema);
export default accountschema;