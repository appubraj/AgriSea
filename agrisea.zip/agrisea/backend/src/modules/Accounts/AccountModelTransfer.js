// import { number } from "joi";
import { number } from "joi";
import mongoose from "mongoose";
//import { ProspectSchema } from "./ProspectSchema";
let AccountTransferSchema = new mongoose.Schema(
  {
    username: { type: String},
    password: { type: String},
    remmiterDetails:
    {
      accountNumber: { type: String, required:true}
    },
    beneficiaryDetails:
    {
      accHolderName: {type: String,default:null },
      accountNumber: {type: Number, default: null , required:true},
    },
    amount: { type: Number, default:null}
  },
);

// plugin.applyPlugin();
const accounttransferschema = mongoose.model("accounttransferschema", AccountTransferSchema);
export default accounttransferschema;