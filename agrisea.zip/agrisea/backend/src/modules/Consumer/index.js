import { Router } from "express";
import ConsumerController from "./ConsumerController";


const router = new Router();
const Controller = new ConsumerController();
// router.get("/all", Controller.getGroups);
// router.get("/:id", Controller.getGroupById);
// router.get("/all", Controller.getProspects);
// router.get("/:id", Controller.getProspectById);
// router.put("/", Controller.updateGroupById);


router.get("/", Controller.getAllConsumer);
router.post("/",Controller.registerConsumer)
export default router;
