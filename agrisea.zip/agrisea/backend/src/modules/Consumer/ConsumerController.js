import consumerModel from "./ConsumerModel";

// import { ProspectSchema } from "./ProspectSchema";
// import _ from "lodash";

const axios = require('axios');
class Consumer {}

Consumer.prototype.registerConsumer = async(req, res) => {
  let consumerObj = req.body

  console.log(consumerObj)
  let model = new consumerModel(consumerObj)
  model.save((err, result) => {
    if (err) {
      console.log(`err `, err)
      if (err.code == 11000) {
        res.send({
          success: false,
          message: 'adar no already exist',
        })
      }
    }
        console.log(result)
        res.send(result)

        // let payload = {
        //     input: {
        //       BidPrice: (result.cropDetails[0].minimumBid).toString(),
        //       CropID: (result.cropDetails[0]._id).toString(),
        //       Date:result.dob,
        //       Grade: result.cropDetails[0].grade,
        //       LandLocation: result.cropDetails[0].landLocation,
        //       Name: result.cropDetails[0].cropName,
        //       OwnerID: (result._id).toString(),
        //       Quantity: result.cropDetails[0].quantity,
        //       Temperature: "31",
        //   }
        // }

    //     const config = {
    //       method: 'post',
    //       url: 'http://127.0.0.1:5000/api/v1/namespaces/default/apis/asset_transfer/invoke/CreateAsset',
    //       data: payload,
    //       }
    //       axios(config)
    //       .then(function (response) {
    //         res.send({
    //           success: true,
    //           message: 'Onboarded Succesfully',
    //         })
    //       })
    //       .catch(function (error) {
    //         res.send(error);
    //       });

    })

}

Consumer.prototype.getAllConsumer = (req, res) => {
  formerModel.find({}, (err, result) => {
    if (err) {
      res.send(err);
    } else {
      res.send(result);
    }
  });
};


export default Consumer;