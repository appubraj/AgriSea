// our example model is just an Array
const facets = [];
export default facets;
