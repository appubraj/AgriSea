import mongoose from "mongoose";
export default (callback) => {
  const options = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
  };
  mongoose.connect(`mongodb+srv://appu:error143@cluster0.gvslo.mongodb.net/agrisea?retryWrites=true&w=majority`, options);
  callback();
};
